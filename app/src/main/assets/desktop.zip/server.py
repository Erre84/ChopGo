#!/usr/bin/env python3
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from urllib.parse import urlparse,parse_qs
import urllib.request,ipaddress,json,pathlib,webbrowser
pairing=None
local_http=urllib.request.build_opener(urllib.request.ProxyHandler({}))
class Server(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def reply(self,status,data=b'',kind='text/plain; charset=utf-8'):
  if isinstance(data,str):data=data.encode()
  self.send_response(status);self.send_header('Content-Type',kind);self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(data)
 def do_GET(self):
  if self.path=='/' or self.path.startswith('/?'):self.reply(200,pathlib.Path(__file__).with_name('index.html').read_bytes(),'text/html; charset=utf-8')
  else:self.reply(404)
 def do_POST(self):
  global pairing
  try:
   if self.headers.get('Origin') not in ('http://localhost:8766','http://127.0.0.1:8766',None):return self.reply(403,'Origen incorrecto')
   length=int(self.headers.get('Content-Length','0'))
   if not 0<length<=65536:return self.reply(400,'Tamaño incorrecto')
   data=self.rfile.read(length)
   if self.path=='/pair':
    value=urlparse(json.loads(data)['url']);ip=ipaddress.ip_address(value.hostname);token=parse_qs(value.query).get('token',[''])[0]
    if value.scheme!='http' or not ip.is_private or ip.is_loopback or value.port!=8765 or len(token)!=32 or any(c not in '0123456789abcdef' for c in token):return self.reply(400,'Pega el enlace completo del teléfono')
    pairing=f'http://{ip}:8765/pcm?token={token}';return self.reply(200,'Emparejado')
   if self.path!='/pcm' or pairing is None or length%4:return self.reply(400,'Empareja primero el teléfono')
   request=urllib.request.Request(pairing,data=data,headers={'Content-Type':'application/octet-stream'},method='POST')
   with local_http.open(request,timeout=4) as response:response.read()
   self.reply(200,'OK')
  except Exception:self.reply(502,'No llega al móvil. Comprueba la Wi-Fi y vuelve a abrir Entrada del ordenador.')
if __name__=='__main__':
 server=ThreadingHTTPServer(('127.0.0.1',8766),Server);print('EXITO PC · http://localhost:8766 · Ctrl+C para cerrar');webbrowser.open('http://localhost:8766');server.serve_forever()
